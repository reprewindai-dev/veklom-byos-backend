"""
x402 Payment Protocol Middleware for Veklom.

Flow:
  1. Request arrives at a paid route
  2. Check for valid Bearer JWT with operating reserve balance
  3. If authenticated + sufficient balance → execute, deduct, return receipt
  4. If unauthenticated or no balance → return 402 with x402 headers
  5. If X-Payment header present → verify payment, execute, return receipt

Every paid response is wrapped with receipt headers.
"""

import json
import uuid
import time
import hashlib
import hmac
import os
import logging
import re
from datetime import datetime, timezone, timedelta
from typing import Optional

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response

from backend.core.config.settings import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Pricing table (mirrors discovery.py — kept in sync)
# ---------------------------------------------------------------------------
_PAID_ROUTES: dict[str, dict] = {
    "/api/v1/ai/inference":        {"price_usdc": 0.008, "name": "AI Inference",       "free_daily": 5},
    "/api/v1/ai/chat":             {"price_usdc": 0.005, "name": "AI Chat",            "free_daily": 5},
    "/api/v1/gpc/compile":         {"price_usdc": 0.015, "name": "GPC Compile",        "free_daily": 3},
    "/api/v1/gpc/intent-to-plan":  {"price_usdc": 0.010, "name": "GPC Intent-to-Plan", "free_daily": 3},
    "/api/v1/gpc/runs":            {"price_usdc": 0.020, "name": "GPC Run",            "free_daily": 0},
    "/api/v1/pipelines/trigger":   {"price_usdc": 0.025, "name": "Pipeline Trigger",   "free_daily": 0},
    "/api/v1/runtime/jobs":        {"price_usdc": 0.020, "name": "Runtime Job",        "free_daily": 0},
    "/api/v1/evidence/export":     {"price_usdc": 0.005, "name": "Evidence Export",    "free_daily": 2},
    "/api/v1/compliance/report":   {"price_usdc": 0.010, "name": "Compliance Report",  "free_daily": 1},
    "/api/v1/marketplace/acquire": {"price_usdc": 0.050, "name": "Marketplace Acquire","free_daily": 0},
    "/api/v1/audit/verify":        {"price_usdc": 0.003, "name": "Audit Verify",       "free_daily": 5},
    "/api/v1/x402/protected-test": {"price_usdc": 0.025, "name": "Protected Test Route", "free_daily": 0},
    "/api/v1/x402/search":         {"price_usdc": 0.10,  "name": "Machine Search",       "free_daily": 0},
    "/api/v1/x402/evaluate":       {"price_usdc": 0.10,  "name": "Machine Evaluate",     "free_daily": 0},
    "/api/v1/x402/governance":     {"price_usdc": 0.10,  "name": "Machine Governance",   "free_daily": 0},
    "/api/v1/x402/score":          {"price_usdc": 0.10,  "name": "Machine Score",        "free_daily": 0},
    "/api/v1/x402/verify":         {"price_usdc": 0.10,  "name": "Machine Verify",       "free_daily": 0},
}

_FREE_ROUTES_PREFIX = (
    "/health", "/status", "/openapi.json", "/.well-known",
    "/llms.txt", "/pricing", "/robots.txt", "/docs", "/redoc",
    "/api/v1/ai/models", "/api/v1/workspace/providers",
    "/api/v1/auth/", "/api/v1/platform/pulse",
    "/api/v1/pricing", "/api/v1/sdk/", "/api/v1/agent-use-cases",
    "/agent-use-cases", "/sdk/examples",
    "/mcp/", "/static/", "/assets/", "/favicon",
    "/api/v1/openapi.json", "/v1/openapi.json",
    "/api/v1/sys/health", "/api/v1/sys/gpu",
    "/api/v1/copilot/registry", "/api/v1/copilot/recent-decisions",
    "/api/v1/integrations/", "/api/v1/receipts", "/api/v1/evidence/verify",
    "/api/v1/x402/config", "/api/v1/x402/verify"
)

VEKLOM_API_BASE   = "https://veklom.com/api/v1"
VEKLOM_TREASURY_DEFAULT = "0xCC34553b4e6332ffb9C1b61E22436ACA53113D1d"
VEKLOM_USDC_ADDR  = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"  # USDC on Base


def is_valid_evm_address(addr: str) -> bool:
    return bool(re.match(r"^0x[a-fA-F0-9]{40}$", addr))

_basename_cache = {}

def resolve_basename(name: str) -> str:
    name_lower = name.strip().lower()
    if not (name_lower.endswith(".base.eth") or name_lower.endswith(".base")):
        return ""
        
    if name_lower in _basename_cache:
        return _basename_cache[name_lower]
        
    if settings.X402_TEST_PROOF_MODE and (name_lower == "veklom.base.eth" or name_lower == "veklom.base"):
        return "0xCC34553b4e6332ffb9C1b61E22436ACA53113D1d"

    label = name_lower.split(".")[0]
    try:
        from web3 import Web3
        token_id = int.from_bytes(Web3.keccak(text=label), byteorder="big")
        
        contract_address = "0x03c4738ee98ae44591e1a4a4f3cab6641d95dd9a"
        abi = [{
            "inputs": [{"internalType": "uint256", "name": "tokenId", "type": "uint256"}],
            "name": "ownerOf",
            "outputs": [{"internalType": "address", "name": "", "type": "address"}],
            "stateMutability": "view",
            "type": "function"
        }]
        
        rpc_url = settings.FLASHBLOCKS_RPC_URL or "https://mainnet.base.org"
        w3 = Web3(Web3.HTTPProvider(rpc_url))
        contract = w3.eth.contract(address=Web3.to_checksum_address(contract_address), abi=abi)
        owner = contract.functions.ownerOf(token_id).call()
        if owner and is_valid_evm_address(owner):
            _basename_cache[name_lower] = owner
            return owner
    except Exception as e:
        logger.warning(f"Basename resolution failed for {name}: {e}")
        if name_lower == "veklom.base.eth" or name_lower == "veklom.base":
            return "0xCC34553b4e6332ffb9C1b61E22436ACA53113D1d"
        
    return ""

def get_treasury_address() -> str:
    raw = os.environ.get("VEKLOM_TREASURY_ADDRESS", "").strip()
    if not raw or raw == "0x0000000000000000000000000000000000000001":
        return ""
    if is_valid_evm_address(raw):
        return raw
    if raw.endswith(".base.eth") or raw.endswith(".base"):
        resolved = resolve_basename(raw)
        if resolved and is_valid_evm_address(resolved):
            return resolved
    return ""

# In-memory free-trial counter: { ip_day_key → count }
_free_usage: dict[str, int] = {}


def _today_key(ip: str) -> str:
    day = datetime.now(timezone.utc).strftime("%Y%m%d")
    return f"{ip}:{day}"


def _get_route_config(path: str) -> Optional[dict]:
    for prefix, cfg in _PAID_ROUTES.items():
        if path.startswith(prefix):
            return cfg
    return None


def _is_free_route(path: str) -> bool:
    for prefix in _FREE_ROUTES_PREFIX:
        if path.startswith(prefix):
            return True
    return False


async def create_and_persist_receipt(
    request: Request,
    route_path: str,
    method: str,
    price_usdc: float,
    tx_hash: str,
    db_session
) -> dict:
    """Generates a cryptographic receipt for audit verification and attempts database persistence."""
    receipt_id = f"rcpt_{uuid.uuid4().hex[:16]}"
    request_id = f"req_{uuid.uuid4().hex[:16]}"
    challenge_id = request.headers.get("X-Payment-Challenge-ID") or f"chal_{uuid.uuid4().hex[:16]}"
    
    proof_hash = hashlib.sha256(tx_hash.encode()).hexdigest()
    
    # Calculate a unique evidence hash seal
    evidence_content = f"{receipt_id}:{request_id}:{tx_hash}:{route_path}"
    evidence_hash = hashlib.sha256(evidence_content.encode()).hexdigest()
    
    receipt = {
        "receipt_id": receipt_id,
        "request_id": request_id,
        "challenge_id": challenge_id,
        "route": route_path,
        "method": method,
        "amount": price_usdc,
        "currency": "USDC",
        "network": "base",
        "chain_id": 8453,
        "payer": request.client.host if request.client else "unknown",
        "pay_to": get_treasury_address(),
        "proof_hash": proof_hash,
        "tx_hash": tx_hash,
        "policy_decision": "passed",
        "execution_status": "completed",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "evidence_hash": evidence_hash,
        "receipt_signature": f"sig_{hashlib.sha256((receipt_id + evidence_hash).encode()).hexdigest()[:24]}",
        "persistence_status": "not_configured"
    }

    if db_session:
        try:
            from backend.db.models.security import AuditLog
            receipt["persistence_status"] = "persisted"
            log = AuditLog(
                workspace_id="default",
                action="x402.receipt.create",
                resource_type="x402_receipt",
                resource_id=receipt_id,
                details=receipt
            )
            db_session.add(log)
            await db_session.commit()
        except Exception as exc:
            logger.error(f"Failed to persist x402 receipt: {exc}")
            receipt["persistence_status"] = "failed"
            receipt["warnings"] = [f"Database error during persistence: {exc}"]
            
    return receipt


def _build_402_response(path: str, method: str, route_config: dict, detail: Optional[str] = None) -> JSONResponse:
    challenge_id = f"chal_{uuid.uuid4().hex[:16]}"
    nonce = f"nonce_{uuid.uuid4().hex[:16]}"
    expires_at = (datetime.now(timezone.utc) + timedelta(seconds=300)).isoformat()
    
    payload = {
        "error": "payment_required",
        "x402_version": "1.0.0",
        "challenge_id": challenge_id,
        "nonce": nonce,
        "amount": route_config["price_usdc"],
        "currency": "USDC",
        "network": "base",
        "chain_id": 8453,
        "pay_to": get_treasury_address(),
        "route": path,
        "method": method,
        "expires_at": expires_at,
        "proof_header_name": "X-Payment-Proof",
        "payment_requirements": {
            "asset_contract": VEKLOM_USDC_ADDR,
            "destination": get_treasury_address(),
            "minimum_amount_micro_usdc": int(route_config["price_usdc"] * 1_000_000)
        },
        "replay_protection": {
            "nonce_required": True,
            "nonce_ttl_seconds": 300,
            "challenge_ttl_seconds": 300
        },
        "receipt_expected": True
    }
    if detail:
        payload["detail"] = detail
        
    headers = {
        "X-Payment-Required": "true",
        "X-Payment-Challenge-ID": challenge_id,
        "X-Payment-Nonce": nonce,
        "X-Payment-Price-USDC": str(route_config["price_usdc"]),
        "X-Payment-Network": "base",
        "X-Payment-Asset": VEKLOM_USDC_ADDR,
        "X-Payment-Address": get_treasury_address(),
        "X-Payment-Scheme": "x402",
        "X-Veklom-Upgrade": "https://veklom.com/pricing",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Expose-Headers": "X-Payment-Required,X-Payment-Price-USDC,X-Payment-Network,X-Payment-Asset,X-Payment-Challenge-ID,X-Payment-Nonce",
    }
    return JSONResponse(payload, status_code=402, headers=headers)


async def _verify_workspace_auth(request: Request) -> Optional[dict]:
    """Check Bearer JWT and return user payload if valid."""
    try:
        from backend.core.security.auth import verify_token
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            token = request.cookies.get("access_token") or request.cookies.get("token")
        else:
            token = auth[7:]
        if not token:
            return None
        return verify_token(token)
    except Exception:
        return None


async def _verify_x402_payment(request: Request, route_config: dict) -> bool:
    """
    Verifies the x402 payment proof header with standard Base Mainnet checks or Dev Test proof bypass.
    Prevent double-spend replay attacks using Redis (fails closed in prod if Redis goes offline).
    """
    import httpx
    from backend.core.database.redis_client import redis_client

    proof = request.headers.get("X-Payment-Proof") or request.headers.get("X-Payment")
    if not proof:
        request.state.x402_error = "missing_payment_proof"
        return False

    proof_str = proof.strip()

    # B1. Base Commerce Payments Integration (Shopify-aligned)
    if proof_str.startswith("xpay_"):
        try:
            from sqlalchemy import select
            from backend.core.database.database import get_db_session
            from backend.db.models.security import AuditLog

            async with get_db_session() as db:
                result = await db.execute(
                    select(AuditLog).where(
                        AuditLog.resource_type == "x402_payment",
                        AuditLog.resource_id == proof_str
                    )
                )
                log_entry = result.scalar_one_or_none()
                if log_entry:
                    details = log_entry.details or {}
                    status = details.get("status")
                    if status in ("authorized", "captured", "charged"):
                        # Replay protection check
                        redis_key = f"x402_tx:{proof_str}"
                        if settings.APP_ENV == "production" and redis_client.is_fallback:
                            request.state.x402_error = "replay_storage_unavailable"
                            return False
                        
                        already_used = await redis_client.get(redis_key)
                        if already_used:
                            request.state.x402_error = "replay_detected"
                            return False
                        
                        required_amount = route_config["price_usdc"]
                        authorized_amount = details.get("amount", 0.0)
                        if authorized_amount >= required_amount:
                            await redis_client.set(redis_key, "used", ex=604800)
                            logger.info(f"[x402] Multi-stage payment {proof_str} verified successfully!")
                            return True
                        else:
                            request.state.x402_error = "insufficient_payment"
                            return False
                    else:
                        request.state.x402_error = "invalid_transaction"
                        return False
        except Exception as exc:
            logger.error(f"[x402] Error verifying multi-stage payment: {exc}")
            request.state.x402_error = "replay_storage_unavailable"
            return False

        request.state.x402_error = "invalid_transaction"
        return False

    # A. Test Proof Mode (Only active if enabled by environment settings and not production)
    if settings.X402_TEST_PROOF_MODE:
        if proof_str.startswith("test_proof_"):
            if "invalid" in proof_str or "fail" in proof_str:
                request.state.x402_error = "invalid_transaction"
                return False
            
            # Replay protection check
            redis_key = f"x402_tx:{proof_str}"
            if settings.APP_ENV == "production" and redis_client.is_fallback:
                request.state.x402_error = "replay_storage_unavailable"
                return False
            
            already_used = await redis_client.get(redis_key)
            if already_used:
                request.state.x402_error = "replay_detected"
                return False
            
            # Lock test proof hash
            await redis_client.set(redis_key, "used", ex=300)
            request.state.test_proof_mode = True
            return True

    # Validate standard transaction hash format
    if not (proof_str.startswith("0x") and len(proof_str) == 66):
        logger.warning(f"[x402] Invalid transaction hash format: {proof_str}")
        request.state.x402_error = "invalid_transaction"
        return False

    # B. Replay Protection - check if the transaction hash was used before
    redis_key = f"x402_tx:{proof_str}"
    
    # In production, if Redis is down (is_fallback is True), fail closed.
    if settings.APP_ENV == "production" and redis_client.is_fallback:
        logger.error("[x402] Replay storage Redis is offline. Failing closed for security.")
        request.state.x402_error = "replay_storage_unavailable"
        return False

    already_used = await redis_client.get(redis_key)
    if already_used:
        logger.warning(f"[x402] Replay attack detected. Tx hash {proof_str} already used.")
        request.state.x402_error = "replay_detected"
        return False

    # C. Mainnet JSON-RPC on Base (incorporating Flashblocks-aware RPC first)
    rpc_endpoints = [settings.FLASHBLOCKS_RPC_URL] if getattr(settings, "FLASHBLOCKS_RPC_URL", "") else []
    rpc_endpoints.extend([
        "https://mainnet.base.org",
        "https://base.llamarpc.com",
        "https://base-rpc.publicnode.com"
    ])

    tx_receipt = None
    rpc_url_used = None
    async with httpx.AsyncClient(timeout=5.0) as client:
        for rpc_url in rpc_endpoints:
            try:
                rpc_payload = {
                    "jsonrpc": "2.0",
                    "method": "eth_getTransactionReceipt",
                    "params": [proof_str],
                    "id": 1
                }
                res = await client.post(rpc_url, json=rpc_payload)
                if res.status_code == 200:
                    data = res.json()
                    if "result" in data and data["result"] is not None:
                        tx_receipt = data["result"]
                        rpc_url_used = rpc_url
                        break
            except Exception as e:
                logger.warning(f"[x402] RPC check failed on {rpc_url}: {e}")
                continue

    if not tx_receipt:
        logger.warning(f"[x402] Could not fetch receipt for transaction hash: {proof_str}")
        request.state.x402_error = "invalid_transaction"
        return False

    # Check transaction status (0x1 = success)
    status = tx_receipt.get("status")
    if status != "0x1":
        logger.warning(f"[x402] Transaction {proof_str} failed or status is not 0x1: {status}")
        request.state.x402_error = "invalid_transaction"
        return False

    # D. Flashblocks-aware required confirmations count set to 0
    required_confirmations = 0
    confirmations = 0
    if tx_receipt.get("blockNumber") and rpc_url_used:
        try:
            tx_block = int(tx_receipt["blockNumber"], 16) if isinstance(tx_receipt["blockNumber"], str) else int(tx_receipt["blockNumber"])
            # Fetch latest block from same RPC
            latest_block = 0
            async with httpx.AsyncClient(timeout=2.0) as block_client:
                rpc_payload = {
                    "jsonrpc": "2.0",
                    "method": "eth_blockNumber",
                    "params": [],
                    "id": 2
                }
                res = await block_client.post(rpc_url_used, json=rpc_payload)
                if res.status_code == 200:
                    data = res.json()
                    if "result" in data:
                        latest_block = int(data["result"], 16) if isinstance(data["result"], str) else int(data["result"])
            if latest_block >= tx_block:
                confirmations = latest_block - tx_block
        except Exception as block_err:
            logger.warning(f"[x402] Failed to calculate confirmations: {block_err}")
            confirmations = 0
            
    if confirmations < required_confirmations:
        logger.warning(f"[x402] Insufficient confirmations: expected={required_confirmations}, found={confirmations}")
        request.state.x402_error = "invalid_transaction"
        return False

    # Parse transfer logs to verify destination and amount in USDC on Base
    usdc_contract = VEKLOM_USDC_ADDR.lower()
    transfer_event_sig = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
    expected_amount = int(route_config["price_usdc"] * 1_000_000)
    treasury_addr = get_treasury_address().lower().strip()

    logs = tx_receipt.get("logs", [])
    actual_amount = 0

    for log in logs:
        log_address = log.get("address", "").lower()
        if log_address != usdc_contract:
            continue

        topics = log.get("topics", [])
        if not topics or topics[0].lower() != transfer_event_sig:
            continue

        if len(topics) < 3:
            continue

        to_topic = topics[2].lower()
        expected_padded = treasury_addr.replace("0x", "").zfill(64)
        if expected_padded not in to_topic:
            continue

        log_data = log.get("data", "")
        if not log_data or log_data == "0x":
            continue

        try:
            val = int(log_data, 16)
            actual_amount += val
        except ValueError:
            continue

    if actual_amount >= expected_amount:
        # Lock hash in redis to prevent double-spend
        await redis_client.set(redis_key, "used", ex=604800)
        logger.info(f"[x402] On-chain payment verified successfully! Tx: {proof_str}")
        return True
    else:
        logger.warning(f"[x402] Payment amount insufficient. Expected={expected_amount}, Found={actual_amount}")
        request.state.x402_error = "insufficient_payment"
        return False


class X402PaymentMiddleware(BaseHTTPMiddleware):
    """x402 payment enforcement middleware."""

    async def dispatch(self, request: Request, call_next) -> Response:
        path = request.url.path
        method = request.method

        # Test-mode bypass — set X402_DISABLED=true to skip all payment enforcement
        if os.environ.get("X402_DISABLED", "").lower() in ("1", "true", "yes"):
            return await call_next(request)

        # Skip OPTIONS and free routes
        if method == "OPTIONS" or _is_free_route(path):
            return await call_next(request)

        route_cfg = _get_route_config(path)
        if route_cfg is None:
            return await call_next(request)

        current_treasury = get_treasury_address()
        if not current_treasury:
            return _build_402_response(path, method, route_cfg, detail="treasury_configuration_invalid")

        request.state.x402_error = "missing_payment_proof"

        # A. Replay protection challenge-level check
        nonce = request.headers.get("X-Payment-Nonce")
        if nonce:
            from backend.core.database.redis_client import redis_client
            redis_key = f"x402_nonce:{nonce}"
            
            if settings.APP_ENV == "production" and redis_client.is_fallback:
                return _build_402_response(path, method, route_cfg, detail="replay_storage_unavailable")
                
            nonce_exists = await redis_client.get(redis_key)
            if nonce_exists:
                return _build_402_response(path, method, route_cfg, detail="replay_detected")
            await redis_client.set(redis_key, "1", ex=300)

        # B. Data sanitisation filter
        if method in ("POST", "PUT", "PATCH"):
            import re
            try:
                body_bytes = await request.body()
                body_str = body_bytes.decode("utf-8", errors="ignore")
                if re.search(r"api_key=|token=|secret=|sk-proj", body_str, re.IGNORECASE):
                    logger.warning("[x402 PII Filter] Sensitive credentials detected in request body.")
                    return JSONResponse(status_code=400, content={"error": "Sensitive data detected"})
                
                async def receive():
                    return {"type": "http.request", "body": body_bytes, "more_body": False}
                request._receive = receive
            except Exception as pii_err:
                logger.error(f"[x402 PII Filter] Error parsing body: {pii_err}")

        # C. Upstream paid gateway trust check
        gateway_secret = request.headers.get("X-Gateway-Secret", "")
        rapidapi_secret = request.headers.get("X-RapidAPI-Proxy-Secret", "")
        
        if gateway_secret or rapidapi_secret:
            configured_secret = settings.UPSTREAM_GATEWAY_SECRET.strip()
            rapidapi_configured_secret = getattr(settings, "RAPIDAPI_PROXY_SECRET", "").strip()
            
            is_valid_gateway = configured_secret and gateway_secret == configured_secret
            is_valid_rapidapi = rapidapi_configured_secret and rapidapi_secret == rapidapi_configured_secret
            
            if is_valid_gateway or is_valid_rapidapi:
                request.state.x402_paid = True
                response = await call_next(request)
                
                # Create and persist a real receipt
                from backend.core.database.database import async_session
                async with async_session() as db:
                    receipt = await create_and_persist_receipt(
                        request, path, method, route_cfg["price_usdc"], "gateway_payment", db
                    )
                
                response.headers["X-Veklom-Receipt-ID"] = receipt["receipt_id"]
                response.headers["X-Veklom-Request-ID"] = receipt["request_id"]
                response.headers["X-Veklom-Evidence-ID"] = receipt["evidence_hash"]
                response.headers["X-Veklom-Cost-USDC"] = str(receipt["amount"])
                response.headers["X-Veklom-Policy-Result"] = receipt["policy_decision"]
                response.headers["X-Veklom-Receipt-URL"] = f"{VEKLOM_API_BASE}/receipts/{receipt['receipt_id']}"
                response.headers["X-Payment-Verified"] = "gateway"
                return response

        # D. JWT verification bypass
        user_payload = await _verify_workspace_auth(request)
        if user_payload:
            user_id = user_payload.get("sub")
            if user_id:
                from sqlalchemy import select, func
                from backend.core.database.database import get_db_session
                from backend.db.models.user import User
                from backend.db.models.workspace import Workspace
                from backend.db.models.ai import ExecutionLog
                from backend.db.models.billing import Subscription, BudgetRule
                from backend.db.models.security import KillSwitchState

                async with get_db_session() as db:
                    user_res = await db.execute(select(User).where(User.id == user_id))
                    db_user = user_res.scalar_one_or_none()
                    
                    if db_user:
                        ws_id = db_user.workspace_id or ""
                        
                        # Kill Switch verification
                        ks_res = await db.execute(
                            select(KillSwitchState).where(
                                KillSwitchState.workspace_id == ws_id,
                                KillSwitchState.is_active == True
                            )
                        )
                        if ks_res.scalar_one_or_none():
                            return JSONResponse(status_code=402, content={"detail": "Emergency halt active."})

                        # Budget constraints verification
                        budget_res = await db.execute(
                            select(BudgetRule).where(
                                BudgetRule.workspace_id == ws_id,
                                BudgetRule.is_active == True
                            )
                        )
                        budget_rules = budget_res.scalars().all()
                        for rule in budget_rules:
                            if rule.current_spend >= rule.limit_usd:
                                return JSONResponse(status_code=402, content={"detail": "Budget limit exceeded."})

                        ws_res = await db.execute(select(Workspace).where(Workspace.id == ws_id))
                        db_ws = ws_res.scalar_one_or_none()
                        plan = db_ws.license_tier.lower() if db_ws and db_ws.license_tier else "free"
                        
                        # 1. Community / Free Tier Constraints (Evaluation Mode)
                        if plan in ("free", "community", "none", None):
                            runs_count = await db.scalar(
                                select(func.count(ExecutionLog.id)).where(ExecutionLog.workspace_id == ws_id)
                            ) or 0
                            if runs_count >= 15:
                                return _build_402_response(path, method, route_cfg, detail="free_runs_exhausted")
                            
                            # Gate advanced features for Community users (Pipelines, Deployments, Custom GPC Runs, Marketplace)
                            free_restricted = (
                                "/api/v1/gpc/runs", "/api/v1/pipelines/trigger",
                                "/api/v1/runtime/jobs", "/api/v1/marketplace/acquire",
                                "/api/v1/compliance/report", "/api/v1/evidence/export"
                            )
                            if any(path.startswith(rf) for rf in free_restricted):
                                return JSONResponse(
                                    status_code=403,
                                    content={
                                        "detail": f"The '{route_cfg.get('name', 'advanced feature')}' requires a Growth plan or higher. Please upgrade at /workspace/#/billing.",
                                        "required_tier": "growth",
                                        "workspace_tier": plan
                                    }
                                )
                        
                        # 2. Growth Tier Constraints
                        elif plan == "growth":
                            # Gate heavy enterprise compliance tools (continuous compliance, raw evidence packages)
                            growth_restricted = ("/api/v1/compliance/report", "/api/v1/evidence/export")
                            if any(path.startswith(sf) for sf in growth_restricted):
                                return JSONResponse(
                                    status_code=403,
                                    content={
                                        "detail": f"Tamper-evident Compliance Reporting & Evidence Export require a Sovereign plan or higher. Please upgrade at /workspace/#/billing.",
                                        "required_tier": "sovereign",
                                        "workspace_tier": plan
                                    }
                                )
                        
                        # Process response
                        response = await call_next(request)
                        if response.status_code < 400:
                            new_log = ExecutionLog(
                                workspace_id=ws_id,
                                user_id=user_id,
                                model=route_cfg.get("name", "Governed Action"),
                                provider="ollama:qwen2.5:3b",
                                cost=route_cfg["price_usdc"],
                                status="completed"
                            )
                            db.add(new_log)
                            await db.commit()
                            
                        # Generate receipt
                        async with get_db_session() as db_receipt:
                            receipt = await create_and_persist_receipt(
                                request, path, method, route_cfg["price_usdc"], "jwt_reserve", db_receipt
                            )
                        response.headers["X-Veklom-Receipt-ID"] = receipt["receipt_id"]
                        response.headers["X-Veklom-Request-ID"] = receipt["request_id"]
                        response.headers["X-Veklom-Evidence-ID"] = receipt["evidence_hash"]
                        response.headers["X-Veklom-Cost-USDC"] = str(receipt["amount"])
                        response.headers["X-Veklom-Policy-Result"] = receipt["policy_decision"]
                        response.headers["X-Veklom-Receipt-URL"] = f"{VEKLOM_API_BASE}/receipts/{receipt['receipt_id']}"
                        return response

        # E. Verify X-Payment-Proof
        if await _verify_x402_payment(request, route_cfg):
            request.state.x402_paid = True
            response = await call_next(request)
            
            tx_hash = request.headers.get("X-Payment-Proof") or request.headers.get("X-Payment") or "test_tx"
            from backend.core.database.database import get_db_session
            async with get_db_session() as db:
                receipt = await create_and_persist_receipt(
                    request, path, method, route_cfg["price_usdc"], tx_hash, db
                )
            
            response.headers["X-Veklom-Receipt-ID"] = receipt["receipt_id"]
            response.headers["X-Veklom-Request-ID"] = receipt["request_id"]
            response.headers["X-Veklom-Evidence-ID"] = receipt["evidence_hash"]
            response.headers["X-Veklom-Cost-USDC"] = str(receipt["amount"])
            response.headers["X-Veklom-Policy-Result"] = receipt["policy_decision"]
            response.headers["X-Veklom-Receipt-URL"] = f"{VEKLOM_API_BASE}/receipts/{receipt['receipt_id']}"
            response.headers["X-Payment-Verified"] = "true"
            if getattr(request.state, "test_proof_mode", False):
                response.headers["X-Payment-Test-Mode"] = "true"
            return response

        # F. Free tier IP daily quota check
        client_ip = request.client.host if request.client else "unknown"
        day_key = _today_key(client_ip)
        daily_limit = route_cfg.get("free_daily", 0)
        used = _free_usage.get(day_key, 0)

        # Skip free daily trial if missing EDGE_API_KEY / fails closed or if route doesn't support it
        if daily_limit > 0 and used < daily_limit:
            _free_usage[day_key] = used + 1
            request.state.x402_paid = True
            response = await call_next(request)
            
            from backend.core.database.database import get_db_session
            async with get_db_session() as db:
                receipt = await create_and_persist_receipt(
                    request, path, method, route_cfg["price_usdc"], "free_trial", db
                )
                
            response.headers["X-Veklom-Free-Trial"] = "true"
            response.headers["X-Veklom-Free-Remaining"] = str(daily_limit - used - 1)
            response.headers["X-Veklom-Receipt-ID"] = receipt["receipt_id"]
            response.headers["X-Veklom-Request-ID"] = receipt["request_id"]
            response.headers["X-Veklom-Evidence-ID"] = receipt["evidence_hash"]
            return response

        # G. Fail with 402 challenge
        return _build_402_response(path, method, route_cfg, detail=request.state.x402_error)
